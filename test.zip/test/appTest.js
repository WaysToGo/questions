var webdriver = require('selenium-webdriver'),
phantomjs = require('phantomjs-prebuilt'),
driver = new webdriver.Builder()
            .withCapabilities({"phantomjs.binary.path":phantomjs.path})
            .forBrowser('phantomjs')
            .build(),
assert = require('chai').assert

describe('App', function() {
describe('default page', function() {
  it('checkBlackColor10', function(done) {
    
    driver.get(process.env.uix_url)
    ele = driver.findElement(webdriver.By.id('black 10'))
    ele.getCssValue('background-color').then(val => {
      assert.equal(val, 'rgba(255, 255, 255, 1)')
      done()
    })
  })

it('checkBlackColor', function(done) {
    
    driver.get(process.env.uix_url)
    ele = driver.findElement(webdriver.By.id('black 20'))
    ele.getCssValue('background-color').then(val => {
      assert.equal(val, 'rgba(0, 0, 0, 1)')
      done()
    })
  })

it('checkBlackColor', function(done) {
    
    driver.get(process.env.uix_url)
    ele = driver.findElement(webdriver.By.id('black 25'))
    ele.getCssValue('background-color').then(val => {
      assert.equal(val, 'rgba(0, 0, 0, 1)')
      done()
    })
  })

it('checkBlackColor', function(done) {
    
    driver.get(process.env.uix_url)
    driver.findElement(webdriver.By.id('input')).sendKeys(6)
    driver.findElement(webdriver.By.id('submit')).click();
    ele = driver.findElement(webdriver.By.id('b7'))
    ele.getCssValue('background-color').then(val => {
      assert.equal(val, 'rgba(255, 255, 255, 1)')
      done()
    })
  })

it('chessboard-f6', function(done) {
    
    driver.get(process.env.uix_url)
    ele = driver.findElement(webdriver.By.id('f6'))
    ele.getCssValue('background-color').then(val => {
      assert.equal(val, 'rgba(0, 0, 0, 1)')
      done()
    })
  })

it('chessboard-c3', function(done) {
    
    driver.get(process.env.uix_url)
    ele = driver.findElement(webdriver.By.id('c3'))
    ele.getCssValue('background-color').then(val => {
      assert.equal(val, 'rgba(0, 0, 0, 1)')
      done()
    })
  })


it('chessboard-e5', function(done) {
    
    driver.get(process.env.uix_url)
    ele = driver.findElement(webdriver.By.id('e5'))
    ele.getCssValue('background-color').then(val => {
      assert.equal(val, 'rgba(0, 0, 0, 1)')
      done()
    })
  })


it('chessboard-h1', function(done) {
    
    driver.get(process.env.uix_url)
    ele = driver.findElement(webdriver.By.id('h1'))
    ele.getCssValue('background-color').then(val => {
      assert.equal(val, 'rgba(255, 255, 255, 1)')
      done()
    })
  })

it('chessboard-g6', function(done) {
    
    driver.get(process.env.uix_url)
    ele = driver.findElement(webdriver.By.id('g6'))
    ele.getCssValue('background-color').then(val => {
      assert.equal(val, 'rgba(255, 255, 255, 1)')
      done()
    })
  })

it('chessboard-d7', function(done) {
    
    driver.get(process.env.uix_url)
    ele = driver.findElement(webdriver.By.id('d7'))
    ele.getCssValue('background-color').then(val => {
      assert.equal(val, 'rgba(255, 255, 255, 1)')
      done()
    })
  })

})
})
