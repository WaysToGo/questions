var app = angular.module("myApp", []);
app.controller("gameController",function($scope){
  $scope.number=5;
  $scope.count=1
  $scope.init= function()
{
var container = document.getElementById("container");
fragment=document.createDocumentFragment();


var createBlock=function(colorName){
     var span=document.createElement('span');
            span.className += colorName;
            if(colorName=="black")span.id="black "+$scope.count++
           fragment.appendChild(span);

}
var i=0,j=0,k=0;
for (i = 1; i <= $scope.number; i++) {
  for (j = 1; j <= $scope.number - i; j++)
  {createBlock("white")}

  for (k = 1; k <= i; k++){
  
     createBlock("black");
     createBlock("white")
   
                          }
                          var div=document.createElement('div');
                                fragment.appendChild(div);


}

for (i = 1; i <= $scope.number; i++) {
  for (j = 1; j <= i; j++) {
  createBlock("white")}

  for (k = 1; k <= $scope.number - i; k++) {
    createBlock("black");
    createBlock("white")
  }
  var div=document.createElement('div');
        fragment.appendChild(div);


}


container.appendChild(fragment);
}

})
// window.onload =